# Rotates through Phantom wallets
print('Rotating wallets...')