# Notifies Telegram with sniper wins
print('Sending Telegram alert...')