# Sells token in waves during pump
print('Auto-selling...')