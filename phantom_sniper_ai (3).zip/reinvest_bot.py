# Reinvests 90%, sends 10% to master wallet
print('Reinvesting...')