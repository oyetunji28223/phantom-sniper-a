# Predicts which coins will pump
print('Predicting...')