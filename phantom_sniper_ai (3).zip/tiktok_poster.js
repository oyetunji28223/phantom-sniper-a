// Posts sniper win to TikTok
console.log('Posting to TikTok...');