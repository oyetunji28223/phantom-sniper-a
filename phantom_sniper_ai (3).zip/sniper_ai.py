# Snipes new meme coins with $0.97
print('Sniping...')